# Copyright © 2020 Giovanni Squillero <squillero@polito.it>
# Free for personal or classroom use; see 'LICENCE.md' for details.
# https://github.com/squillero/computer-sciences

for n in range(0, 100):
    if n == 42:
        print(f"Whoa! n is exactly {n}!!!!!")
