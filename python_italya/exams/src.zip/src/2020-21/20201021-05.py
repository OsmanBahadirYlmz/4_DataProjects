# Copyright © 2020 Giovanni Squillero <squillero@polito.it>
# Free for personal or classroom use; see 'LICENCE.md' for details.
# https://github.com/squillero/computer-sciences

name = input("What is your name? ")

if name.upper() == "BOB":
    print(f"Hi {name}!")
