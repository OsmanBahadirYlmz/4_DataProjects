# Copyright © 2020 Giovanni Squillero <squillero@polito.it>
# Free for personal or classroom use; see 'LICENCE.md' for details.
# https://github.com/squillero/computer-sciences


def main():
    for n in range(10):
        print(f"n IS NOW {n} (yes, I'm SHOUTING)")


if __name__ == '__main__':  # BLACK MAGIC!
    main()
